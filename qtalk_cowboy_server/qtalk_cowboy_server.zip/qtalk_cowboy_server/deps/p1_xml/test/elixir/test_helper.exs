ExUnit.start()
# Mix is starting application p1_xml automatically
