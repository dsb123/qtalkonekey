# p1_pgsql

**This repository is deprecated as it moved to [p1_pgsql](https://github.com/processone/p1_pgsql/).**

Pure Erlang PostgreSQL driver
