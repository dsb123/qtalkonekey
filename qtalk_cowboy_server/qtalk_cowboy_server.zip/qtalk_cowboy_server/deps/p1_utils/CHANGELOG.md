# Version 1.0.3

* Added time related compatibility module, added API documentation (Paweł Chmielowski)
* Improve documentation readability (Marek Foss)

# Version 1.0.2

* Add p1_time_compat module to ease support for both R17 and R18 Erlang time features (Paweł Chmielowski)

# Version 1.0.1

* Better Rebar3 support, remove warning about missing hex plugin when
  building with rebar (Mickaël Rémond)
